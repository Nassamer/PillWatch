/*package com.example.loginv3;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothSocket;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.content.Context;
import android.util.Log;

import java.io.IOException;
import java.util.UUID;

public class BlueToothConnectivity
{
    private static final String TAG = "MarcusPhone";
    private static final String appName = "PILLWATCHBLUETOOTH";

    //Ez szinte biztos hogy más, ezt még ki kell találni
    private static final UUID MY_UUID_INSECURE = UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66");

    private final BluetoothAdapter mAdapter;
    Context mcontext;

    private AcceptThread mInsecureAcceptThread;
    private ConnectThread mConnectThread;

    public BlueToothConnectivity(Context context)
    {
        mcontext=context;
        mAdapter=BluetoothAdapter.getDefaultAdapter();
    }

    //Thread, ez kell a connectionhoz
    private class AcceptThread extends Thread
    {
        private final BluetoothServerSocket mmServerSocket;

        public AcceptThread()
        {
            BluetoothServerSocket tmp = null;
            try {
                tmp = mAdapter.listenUsingInsecureRfcommWithServiceRecord(appName, MY_UUID_INSECURE);

                Log.e(TAG,"Sikeres kapcsolat");

            }catch (IOException e){
                Log.e(TAG, "Socket listen() failed", e);
            }
            mmServerSocket =tmp;
        }

        public void run()
        {
            Log.d(TAG, "BEGIN mAcceptThread");
            BluetoothSocket socket=null;

            try {
                socket = mmServerSocket.accept();
            } catch (IOException e) {
                Log.e(TAG,  "accept() failed", e);

            }

            if(socket !=null)
            {
                connected(socket,mmDevice);
            }


        }

        public void cancel( )
        {
            Log.d(TAG, "Socket cancel ");
            try
            {
                mmServerSocket.close();
            }
            catch (IOException e)
            {
                Log.e(TAG, "Socket close() of server failed", e);
            }
        }
    }
}
*/