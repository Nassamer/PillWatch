package com.example.loginv3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class TableAdapter extends RecyclerView.Adapter<TableAdapter.TableViewHolder> {


    Context context;

    ArrayList<Adat> list;

    public TableAdapter(Context context, ArrayList<Adat> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public TableViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.usertable,parent,false);
        return new TableViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull TableViewHolder holder, int position) {

        Adat adat = list.get(position);
        holder.alarmState.setText(adat.getAlarmState());
        holder.alarmTime.setText(adat.getAlarmTime());
        holder.binState.setText(adat.getBinState());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class TableViewHolder extends RecyclerView.ViewHolder{

        TextView alarmState, alarmTime, binState;

        public TableViewHolder(@NonNull View itemView) {
            super(itemView);

            alarmState = itemView.findViewById(R.id.alarmState);
            alarmTime = itemView.findViewById(R.id.alarmTime);
            binState = itemView.findViewById(R.id.binState);
        }
    }
}
