package com.example.loginv3;

public class Adat {
    private String alarmState;
    private String alarmTime;
    private String binState;


    public Adat(String alarmState, String alarmTime, String binState) {
        this.alarmState = alarmState;
        this.alarmTime = alarmTime;
        this.binState = binState;

    }

    public Adat() {
    }

    public String getAlarmState() {
        return alarmState;
    }

    public void setAlarmState(String alarmState) {
        this.alarmState = alarmState;
    }

    public String getAlarmTime() {
        return alarmTime;
    }

    public void setAlarmTime(String alarmTime) {
        this.alarmTime = alarmTime;
    }

    public String getBinState() {
        return binState;
    }

    public void setBinState(String binState) {
        this.binState = binState;
    }


}
