package com.example.loginv3;

public class Adat {
    private String alarmState;
    private String alarmTime;
    private String binState;
    //hardvare ellenorzlslhez kell csak
    private int baseValue;
    private int currentValue;

    public Adat(String alarmState, String alarmTime, String binState, int baseValue, int currentValue) {
        this.alarmState = alarmState;
        this.alarmTime = alarmTime;
        this.binState = binState;
        this.baseValue = baseValue;
        this.currentValue = currentValue;
    }

    public Adat() {
    }

    public String getAlarmState() {
        return alarmState;
    }

    public void setAlarmState(String alarmState) {
        this.alarmState = alarmState;
    }

    public String getAlarmTime() {
        return alarmTime;
    }

    public void setAlarmTime(String alarmTime) {
        this.alarmTime = alarmTime;
    }

    public String getBinState() {
        return binState;
    }

    public void setBinState(String binState) {
        this.binState = binState;
    }

    public int getBaseValue() {
        return baseValue;
    }

    public void setBaseValue(int baseValue) {
        this.baseValue = baseValue;
    }

    public int getCurrentValue() {
        return currentValue;
    }

    public void setCurrentValue(int currentValue) {
        this.currentValue = currentValue;
    }
}
