package com.example.loginv3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BlueToothActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blue_tooth);
    }
}